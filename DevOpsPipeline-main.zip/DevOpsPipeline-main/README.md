# DevOps Pipeline
 Java-J2EE Web App, Maven - Code for DevOps Implementation